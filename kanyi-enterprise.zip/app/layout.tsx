import type React from "react"
import { Inter } from "next/font/google"
import Link from "next/link"
import { ThemeProvider } from "@/components/theme-provider"
import { Button } from "@/components/ui/button"
import { Facebook, Instagram, Linkedin, Mail, MapPin, Phone } from "lucide-react"
import "./globals.css"
import MobileNav from "@/components/mobile-nav"
import ThemeToggle from "@/components/theme-toggle"
import ScrollToTop from "@/components/scroll-to-top"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "Kanyi's Enterprise - Construction Materials Export",
  description: "Premium construction materials exported from Turkey to The Gambia",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body>
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:absolute focus:z-[100] focus:p-4 focus:bg-white focus:text-black"
        >
          Skip to main content
        </a>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
          <div className="flex flex-col min-h-screen">
            {/* Top Bar */}
            <div className="bg-primary text-primary-foreground py-2 hidden md:block">
              <div className="container mx-auto px-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-4 text-sm">
                    <div className="flex items-center">
                      <Phone className="h-4 w-4 mr-2" />
                      <span>+220 123 4567</span>
                    </div>
                    <div className="flex items-center">
                      <Mail className="h-4 w-4 mr-2" />
                      <span>info@kanyisenterprise.com</span>
                    </div>
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 mr-2" />
                      <span>123 Kairaba Avenue, Serrekunda, The Gambia</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <a href="#" aria-label="Facebook">
                      <Facebook className="h-4 w-4" />
                    </a>
                    <a href="#" aria-label="Instagram">
                      <Instagram className="h-4 w-4" />
                    </a>
                    <a href="#" aria-label="LinkedIn">
                      <Linkedin className="h-4 w-4" />
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Header */}
            <header className="bg-white border-b sticky top-0 z-50">
              <div className="container mx-auto px-4">
                <div className="flex justify-between items-center py-4">
                  <Link href="/" className="text-2xl font-bold text-primary">
                    Kanyi's Enterprise
                  </Link>
                  <nav className="hidden md:flex items-center space-x-8">
                    <Link href="/" className="font-medium hover:text-primary transition-colors">
                      Home
                    </Link>
                    <Link href="/about" className="font-medium hover:text-primary transition-colors">
                      About
                    </Link>
                    <Link href="/products" className="font-medium hover:text-primary transition-colors">
                      Products
                    </Link>
                    <Link href="/blog" className="font-medium hover:text-primary transition-colors">
                      Blog
                    </Link>
                    <Link href="/contact" className="font-medium hover:text-primary transition-colors">
                      Contact
                    </Link>
                  </nav>
                  <div className="hidden md:flex items-center gap-2">
                    <ThemeToggle />
                    <Button asChild>
                      <Link href="/contact">Get a Quote</Link>
                    </Button>
                  </div>
                  <MobileNav />
                </div>
              </div>
            </header>

            {/* Main Content */}
            <div id="main-content" className="flex-grow">
              {children}
            </div>

            {/* Footer */}
            <footer className="bg-gray-900 text-gray-300">
              <div className="container mx-auto px-4 py-12">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                  <div>
                    <h3 className="text-white text-lg font-semibold mb-4">About Us</h3>
                    <p className="mb-4">
                      Kanyi's Enterprise is a leading provider of construction materials, specializing in sourcing and
                      exporting premium building supplies from Turkey to The Gambia.
                    </p>
                    <div className="flex space-x-4">
                      <a href="#" aria-label="Facebook" className="hover:text-white">
                        <Facebook className="h-5 w-5" />
                      </a>
                      <a href="#" aria-label="Instagram" className="hover:text-white">
                        <Instagram className="h-5 w-5" />
                      </a>
                      <a href="#" aria-label="LinkedIn" className="hover:text-white">
                        <Linkedin className="h-5 w-5" />
                      </a>
                    </div>
                  </div>
                  <div>
                    <h3 className="text-white text-lg font-semibold mb-4">Quick Links</h3>
                    <ul className="space-y-2">
                      <li>
                        <Link href="/" className="hover:text-white transition-colors">
                          Home
                        </Link>
                      </li>
                      <li>
                        <Link href="/about" className="hover:text-white transition-colors">
                          About Us
                        </Link>
                      </li>
                      <li>
                        <Link href="/products" className="hover:text-white transition-colors">
                          Products
                        </Link>
                      </li>
                      <li>
                        <Link href="/blog" className="hover:text-white transition-colors">
                          Blog
                        </Link>
                      </li>
                      <li>
                        <Link href="/contact" className="hover:text-white transition-colors">
                          Contact Us
                        </Link>
                      </li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="text-white text-lg font-semibold mb-4">Products</h3>
                    <ul className="space-y-2">
                      <li>
                        <Link href="/products" className="hover:text-white transition-colors">
                          Cement
                        </Link>
                      </li>
                      <li>
                        <Link href="/products" className="hover:text-white transition-colors">
                          Steel
                        </Link>
                      </li>
                      <li>
                        <Link href="/products" className="hover:text-white transition-colors">
                          Tiles
                        </Link>
                      </li>
                      <li>
                        <Link href="/products" className="hover:text-white transition-colors">
                          Roofing Materials
                        </Link>
                      </li>
                      <li>
                        <Link href="/products" className="hover:text-white transition-colors">
                          Plumbing Supplies
                        </Link>
                      </li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="text-white text-lg font-semibold mb-4">Contact Info</h3>
                    <ul className="space-y-3">
                      <li className="flex items-start">
                        <MapPin className="h-5 w-5 mr-3 mt-1 flex-shrink-0" />
                        <span>123 Kairaba Avenue, Serrekunda, The Gambia</span>
                      </li>
                      <li className="flex items-center">
                        <Phone className="h-5 w-5 mr-3 flex-shrink-0" />
                        <span>+220 123 4567</span>
                      </li>
                      <li className="flex items-center">
                        <Mail className="h-5 w-5 mr-3 flex-shrink-0" />
                        <span>info@kanyisenterprise.com</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="border-t border-gray-800 py-6">
                <div className="container mx-auto px-4 text-center">
                  <p>&copy; {new Date().getFullYear()} Kanyi's Enterprise. All rights reserved.</p>
                </div>
              </div>
            </footer>
            <ScrollToTop />
          </div>
        </ThemeProvider>
      </body>
    </html>
  )
}



import './globals.css'