import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Calendar, User, ArrowLeft, Facebook, Twitter, Linkedin } from "lucide-react"
import { notFound } from "next/navigation"

// Sample blog posts data
const blogPosts = [
  {
    id: 1,
    title: "The Future of Construction Materials in The Gambia",
    excerpt:
      "Exploring emerging trends and innovations in construction materials that are shaping the future of building in The Gambia.",
    content: `
      <p>The construction industry in The Gambia is undergoing significant transformation, driven by technological advancements, sustainability concerns, and changing market demands. As we look to the future, several key trends are emerging in construction materials that promise to reshape how buildings are constructed in The Gambia.</p>
      
      <h2>Sustainable Materials</h2>
      <p>Sustainability is becoming increasingly important in construction. Materials that minimize environmental impact while maintaining structural integrity are gaining popularity. These include:</p>
      <ul>
        <li>Recycled steel and aluminum</li>
        <li>Bamboo-reinforced concrete</li>
        <li>Locally-sourced natural materials</li>
        <li>Low-carbon cement alternatives</li>
      </ul>
      
      <h2>Advanced Concrete Formulations</h2>
      <p>Concrete remains a fundamental building material, but new formulations are enhancing its properties:</p>
      <ul>
        <li>Self-healing concrete that can repair its own cracks</li>
        <li>Ultra-high-performance concrete with exceptional strength</li>
        <li>Permeable concrete that allows water to pass through, reducing flooding risks</li>
      </ul>
      
      <h2>Smart Materials</h2>
      <p>The integration of technology into building materials is creating "smart" options that can respond to environmental changes:</p>
      <ul>
        <li>Photovoltaic glass that generates electricity</li>
        <li>Thermochromic materials that change properties based on temperature</li>
        <li>Self-cleaning surfaces that reduce maintenance needs</li>
      </ul>
      
      <h2>Prefabricated Components</h2>
      <p>Prefabrication is revolutionizing construction efficiency:</p>
      <ul>
        <li>Factory-produced wall and floor panels</li>
        <li>Modular building systems</li>
        <li>3D-printed structural elements</li>
      </ul>
      
      <h2>Conclusion</h2>
      <p>The future of construction materials in The Gambia looks promising, with innovations that will make buildings more sustainable, durable, and efficient. At Kanyi's Enterprise, we're committed to staying at the forefront of these developments, bringing the best materials to our clients to help build a better future for The Gambia.</p>
    `,
    date: "March 15, 2023",
    author: "Lamin Kanyi",
    image: "/placeholder.svg?text=Future+Construction+Materials&height=800&width=1200",
    slug: "future-construction-materials-gambia",
  },
  {
    id: 2,
    title: "How to Choose the Right Cement for Your Project",
    excerpt:
      "A comprehensive guide to understanding different types of cement and selecting the best one for your specific construction needs.",
    content: `
      <p>Cement is the foundation of most construction projects, but not all cement is created equal. Choosing the right type for your specific project can significantly impact durability, strength, and overall performance. This guide will help you navigate the different options available.</p>
      
      <h2>Understanding Cement Types</h2>
      <p>There are several types of cement, each with specific properties and applications:</p>
      
      <h3>Ordinary Portland Cement (OPC)</h3>
      <p>The most common type of cement, available in different grades (33, 43, and 53) indicating compressive strength. OPC is versatile and suitable for general construction work including:</p>
      <ul>
        <li>Residential buildings</li>
        <li>Commercial structures</li>
        <li>Roads and pavements</li>
      </ul>
      
      <h3>Portland Pozzolana Cement (PPC)</h3>
      <p>Contains pozzolanic materials that improve durability and resistance to chemical attacks. Ideal for:</p>
      <ul>
        <li>Marine structures</li>
        <li>Sewage works</li>
        <li>Water treatment plants</li>
      </ul>
      
      <h3>Rapid Hardening Cement</h3>
      <p>Achieves high strength in a short time, making it perfect for:</p>
      <ul>
        <li>Emergency repairs</li>
        <li>Cold weather construction</li>
        <li>Projects requiring quick form removal</li>
      </ul>
      
      <h3>Sulfate Resistant Cement</h3>
      <p>Designed to resist sulfate attacks, suitable for:</p>
      <ul>
        <li>Foundations in sulfate-rich soils</li>
        <li>Coastal structures</li>
        <li>Underground constructions</li>
      </ul>
      
      <h2>Factors to Consider When Choosing Cement</h2>
      
      <h3>Project Requirements</h3>
      <p>Consider the specific needs of your project:</p>
      <ul>
        <li>Required strength</li>
        <li>Setting time</li>
        <li>Resistance to environmental factors</li>
      </ul>
      
      <h3>Environmental Conditions</h3>
      <p>The environment where the structure will be built affects cement choice:</p>
      <ul>
        <li>Coastal areas (high salt content)</li>
        <li>Industrial zones (chemical exposure)</li>
        <li>Temperature extremes</li>
      </ul>
      
      <h3>Budget Considerations</h3>
      <p>Different cement types come at different price points. Balance cost with performance requirements.</p>
      
      <h2>Conclusion</h2>
      <p>Selecting the right cement is crucial for the success of your construction project. At Kanyi's Enterprise, we offer a wide range of high-quality cement options and can provide expert advice on which type is best suited for your specific needs. Contact us to discuss your project requirements and ensure you're building on a solid foundation.</p>
    `,
    date: "February 28, 2023",
    author: "Fatou Jallow",
    image: "/placeholder.svg?text=Cement+Types&height=800&width=1200",
    slug: "choose-right-cement-project",
  },
]

export default function BlogPostPage({ params }: { params: { slug: string } }) {
  const post = blogPosts.find((post) => post.slug === params.slug)

  if (!post) {
    notFound()
  }

  // Find related posts (excluding the current post)
  const relatedPosts = blogPosts.filter((relatedPost) => relatedPost.id !== post.id).slice(0, 2)

  return (
    <main className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[50vh] w-full">
        <div className="absolute inset-0 bg-black/60 z-10" />
        <div
          className="absolute inset-0 bg-cover bg-center z-0"
          style={{
            backgroundImage: `url(${post.image})`,
          }}
        />
        <div className="relative z-20 container mx-auto px-4 h-full flex flex-col justify-center">
          <h1 className="text-3xl md:text-5xl font-bold text-white mb-4">{post.title}</h1>
          <div className="flex items-center gap-4 text-white/90">
            <div className="flex items-center">
              <Calendar className="h-4 w-4 mr-1" />
              {post.date}
            </div>
            <div className="flex items-center">
              <User className="h-4 w-4 mr-1" />
              {post.author}
            </div>
          </div>
        </div>
      </section>

      {/* Blog Content */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <Button variant="ghost" className="mb-8" asChild>
              <Link href="/blog">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Blog
              </Link>
            </Button>

            <article className="prose prose-lg max-w-none">
              <div dangerouslySetInnerHTML={{ __html: post.content }} />
            </article>

            {/* Share Links */}
            <div className="mt-12 pt-8 border-t">
              <h3 className="text-lg font-semibold mb-4">Share this article</h3>
              <div className="flex space-x-4">
                <Button variant="outline" size="icon" aria-label="Share on Facebook">
                  <Facebook className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon" aria-label="Share on Twitter">
                  <Twitter className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon" aria-label="Share on LinkedIn">
                  <Linkedin className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Related Posts */}
            <div className="mt-12 pt-8 border-t">
              <h3 className="text-lg font-semibold mb-4">Related Articles</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {relatedPosts.map((relatedPost) => (
                  <div key={relatedPost.id} className="border rounded-lg overflow-hidden">
                    <Link href={`/blog/${relatedPost.slug}`}>
                      <div className="h-40 overflow-hidden">
                        <Image
                          src={relatedPost.image || "/placeholder.svg"}
                          alt={relatedPost.title}
                          width={600}
                          height={400}
                          className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                        />
                      </div>
                    </Link>
                    <div className="p-4">
                      <Link href={`/blog/${relatedPost.slug}`}>
                        <h4 className="font-semibold hover:text-primary transition-colors mb-2">{relatedPost.title}</h4>
                      </Link>
                      <p className="text-sm text-gray-600">{relatedPost.date}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}

