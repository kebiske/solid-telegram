import { Input } from "@/components/ui/input"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Calendar, User } from "lucide-react"

// Sample blog posts data
const blogPosts = [
  {
    id: 1,
    title: "The Future of Construction Materials in The Gambia",
    excerpt:
      "Exploring emerging trends and innovations in construction materials that are shaping the future of building in The Gambia.",
    date: "March 15, 2023",
    author: "Lamin Kanyi",
    image: "/placeholder.svg?text=Future+Construction+Materials&height=400&width=600",
    slug: "future-construction-materials-gambia",
  },
  {
    id: 2,
    title: "How to Choose the Right Cement for Your Project",
    excerpt:
      "A comprehensive guide to understanding different types of cement and selecting the best one for your specific construction needs.",
    date: "February 28, 2023",
    author: "Fatou Jallow",
    image: "/placeholder.svg?text=Cement+Types&height=400&width=600",
    slug: "choose-right-cement-project",
  },
  {
    id: 3,
    title: "Sustainable Building Practices in West Africa",
    excerpt:
      "Discover how sustainable building practices are being adopted across West Africa and how they can benefit your construction projects.",
    date: "January 20, 2023",
    author: "Omar Ceesay",
    image: "/placeholder.svg?text=Sustainable+Building&height=400&width=600",
    slug: "sustainable-building-practices-west-africa",
  },
  {
    id: 4,
    title: "Importing Construction Materials: A Step-by-Step Guide",
    excerpt:
      "Navigate the complexities of importing construction materials with our comprehensive guide to regulations, logistics, and best practices.",
    date: "December 12, 2022",
    author: "Lamin Kanyi",
    image: "/placeholder.svg?text=Importing+Materials&height=400&width=600",
    slug: "importing-construction-materials-guide",
  },
  {
    id: 5,
    title: "Cost-Effective Building Solutions for Residential Projects",
    excerpt:
      "Learn how to optimize your budget without compromising on quality with these cost-effective building solutions for residential construction.",
    date: "November 5, 2022",
    author: "Fatou Jallow",
    image: "/placeholder.svg?text=Cost+Effective+Building&height=400&width=600",
    slug: "cost-effective-building-solutions",
  },
  {
    id: 6,
    title: "The Impact of Quality Materials on Building Longevity",
    excerpt:
      "Understand how investing in quality construction materials can significantly extend the lifespan of your buildings and reduce maintenance costs.",
    date: "October 18, 2022",
    author: "Omar Ceesay",
    image: "/placeholder.svg?text=Quality+Materials+Impact&height=400&width=600",
    slug: "quality-materials-building-longevity",
  },
]

export default function BlogPage() {
  return (
    <main className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[40vh] w-full">
        <div className="absolute inset-0 bg-black/60 z-10" />
        <div
          className="absolute inset-0 bg-cover bg-center z-0"
          style={{
            backgroundImage: "url('/placeholder.svg?text=Construction+Blog&height=800&width=1600')",
          }}
        />
        <div className="relative z-20 container mx-auto px-4 h-full flex flex-col justify-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Blog & News</h1>
          <p className="text-xl text-white/90 max-w-2xl">
            Stay updated with the latest industry insights and company news
          </p>
        </div>
      </section>

      {/* Blog Posts */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post) => (
              <article key={post.id} className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-100">
                <Link href={`/blog/${post.slug}`}>
                  <div className="h-48 overflow-hidden">
                    <Image
                      src={post.image || "/placeholder.svg"}
                      alt={post.title}
                      width={600}
                      height={400}
                      className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                    />
                  </div>
                </Link>
                <div className="p-6">
                  <div className="flex items-center gap-4 text-sm text-gray-500 mb-3">
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      {post.date}
                    </div>
                    <div className="flex items-center">
                      <User className="h-4 w-4 mr-1" />
                      {post.author}
                    </div>
                  </div>
                  <Link href={`/blog/${post.slug}`}>
                    <h2 className="text-xl font-bold mb-3 hover:text-primary transition-colors">{post.title}</h2>
                  </Link>
                  <p className="text-gray-600 mb-4">{post.excerpt}</p>
                  <Button variant="outline" asChild>
                    <Link href={`/blog/${post.slug}`}>Read More</Link>
                  </Button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 max-w-4xl text-center">
          <h2 className="text-3xl font-bold mb-6">Subscribe to Our Newsletter</h2>
          <p className="text-gray-700 mb-8">
            Stay updated with the latest industry news, product updates, and special offers.
          </p>
          <form className="flex flex-col sm:flex-row gap-3 max-w-lg mx-auto">
            <Input type="email" placeholder="Your email address" className="flex-grow" required />
            <Button type="submit">Subscribe</Button>
          </form>
        </div>
      </section>
    </main>
  )
}

