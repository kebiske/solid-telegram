import Link from "next/link"
import Image from "next/image"
import { ArrowRight, Building2, CheckCircle, Phone, TrendingUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import ProductCard from "@/components/product-card"
import TestimonialCard from "@/components/testimonial-card"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col">
      {/* Hero Section */}
      <section className="relative h-[80vh] w-full overflow-hidden">
        <div className="absolute inset-0 bg-black/50 z-10" />
        <div
          className="absolute inset-0 bg-cover bg-center z-0 scale-105 animate-[pulse_15s_ease-in-out_infinite]"
          style={{
            backgroundImage: "url('/placeholder.svg?text=Construction+Site+in+The+Gambia&height=1080&width=1920')",
          }}
        />
        <div className="relative z-20 container mx-auto px-4 h-full flex flex-col justify-center">
          <div className="animate-[fadeIn_1s_ease-in-out]">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">Premium Construction Materials</h1>
            <p className="text-xl md:text-2xl text-white/90 mb-8 max-w-2xl">
              Sourcing and exporting high-quality construction materials from Turkey to The Gambia
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" asChild className="animate-[fadeIn_1.2s_ease-in-out]">
                <Link href="/contact">
                  Get a Quote <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="bg-white/10 text-white border-white/20 hover:bg-white/20 animate-[fadeIn_1.4s_ease-in-out]"
                asChild
              >
                <Link href="/products">Explore Products</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Introduction Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row gap-12 items-center">
            <div className="md:w-1/2">
              <h2 className="text-3xl font-bold mb-6">Welcome to Kanyi's Enterprise</h2>
              <p className="text-gray-700 mb-6">
                Kanyi's Enterprise is a leading provider of construction materials, specializing in sourcing and
                exporting premium building supplies from Turkey to The Gambia. With years of experience in the industry,
                we ensure that our clients receive the highest quality materials at competitive prices.
              </p>
              <p className="text-gray-700 mb-8">
                Our extensive network of suppliers and efficient logistics solutions make us the preferred partner for
                construction companies, contractors, and individual builders across The Gambia.
              </p>
              <Button asChild>
                <Link href="/about">Learn More About Us</Link>
              </Button>
            </div>
            <div className="md:w-1/2">
              <Image
                src="/placeholder.svg?text=Construction+Materials+Warehouse&height=600&width=800"
                alt="Construction materials warehouse"
                width={800}
                height={600}
                className="rounded-lg shadow-lg w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose Kanyi's Enterprise</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="bg-primary/10 p-3 rounded-full w-fit mb-4">
                <CheckCircle className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Quality Assurance</h3>
              <p className="text-gray-700">
                We source only the highest quality materials from trusted manufacturers in Turkey, ensuring durability
                and reliability.
              </p>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="bg-primary/10 p-3 rounded-full w-fit mb-4">
                <TrendingUp className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Competitive Pricing</h3>
              <p className="text-gray-700">
                Our direct relationships with manufacturers and efficient supply chain allow us to offer the most
                competitive prices in the market.
              </p>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="bg-primary/10 p-3 rounded-full w-fit mb-4">
                <Building2 className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Logistics Excellence</h3>
              <p className="text-gray-700">
                We handle all aspects of shipping, customs clearance, and delivery, ensuring your materials arrive on
                time and in perfect condition.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-12">
            <h2 className="text-3xl font-bold">Featured Products</h2>
            <Button variant="outline" asChild>
              <Link href="/products">View All Products</Link>
            </Button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            <ProductCard
              title="Premium Cement"
              description="High-quality cement for all construction needs"
              image="/placeholder.svg?text=Premium+Cement+Bags&height=400&width=600"
            />
            <ProductCard
              title="Reinforcement Steel"
              description="Durable steel bars for structural reinforcement"
              image="/placeholder.svg?text=Steel+Reinforcement+Bars&height=400&width=600"
            />
            <ProductCard
              title="Ceramic Tiles"
              description="Elegant and durable tiles for floors and walls"
              image="/placeholder.svg?text=Ceramic+Floor+Tiles&height=400&width=600"
            />
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">What Our Clients Say</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <TestimonialCard
              quote="Kanyi's Enterprise has been our trusted supplier for over 3 years. Their materials are top-notch and their service is exceptional."
              author="Ibrahim Jallow"
              company="Jallow Construction Ltd"
            />
            <TestimonialCard
              quote="The quality of materials and timely delivery have made Kanyi's Enterprise our go-to supplier for all our construction projects."
              author="Fatou Ceesay"
              company="Ceesay Builders"
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Start Your Project?</h2>
          <p className="text-white/90 max-w-2xl mx-auto mb-8">
            Contact us today to discuss your construction material needs and get a personalized quote.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" asChild>
              <Link href="/contact">
                Contact Us <Phone className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" className="border-white/20 hover:bg-white/10" asChild>
              <Link href="/products">Browse Products</Link>
            </Button>
          </div>
        </div>
      </section>
    </main>
  )
}

