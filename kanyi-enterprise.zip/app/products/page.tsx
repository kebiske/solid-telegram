"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import ProductCard from "@/components/product-card"
import { Search } from "lucide-react"

// Product data
const products = [
  {
    id: 1,
    title: "Premium Cement",
    category: "cement",
    description: "High-quality cement for all construction needs",
    image: "/placeholder.svg?text=Premium+Cement&height=400&width=600",
  },
  {
    id: 2,
    title: "Reinforcement Steel",
    category: "steel",
    description: "Durable steel bars for structural reinforcement",
    image: "/placeholder.svg?text=Steel+Bars&height=400&width=600",
  },
  {
    id: 3,
    title: "Ceramic Tiles",
    category: "tiles",
    description: "Elegant and durable tiles for floors and walls",
    image: "/placeholder.svg?text=Ceramic+Tiles&height=400&width=600",
  },
  {
    id: 4,
    title: "Concrete Blocks",
    category: "blocks",
    description: "Solid concrete blocks for walls and foundations",
    image: "/placeholder.svg?text=Concrete+Blocks&height=400&width=600",
  },
  {
    id: 5,
    title: "Roofing Sheets",
    category: "roofing",
    description: "Durable metal roofing sheets for all weather conditions",
    image: "/placeholder.svg?text=Metal+Roofing&height=400&width=600",
  },
  {
    id: 6,
    title: "PVC Pipes",
    category: "plumbing",
    description: "High-quality PVC pipes for plumbing systems",
    image: "/placeholder.svg?text=PVC+Pipes&height=400&width=600",
  },
  {
    id: 7,
    title: "Electrical Wiring",
    category: "electrical",
    description: "Safe and reliable electrical wiring for all applications",
    image: "/placeholder.svg?text=Electrical+Wiring&height=400&width=600",
  },
  {
    id: 8,
    title: "Paint",
    category: "paint",
    description: "Premium quality paint for interior and exterior surfaces",
    image: "/placeholder.svg?text=Premium+Paint&height=400&width=600",
  },
  {
    id: 9,
    title: "Glass Panels",
    category: "glass",
    description: "Clear and tinted glass panels for windows and doors",
    image: "/placeholder.svg?text=Glass+Panels&height=400&width=600",
  },
]

// Categories
const categories = [
  { value: "all", label: "All Categories" },
  { value: "cement", label: "Cement" },
  { value: "steel", label: "Steel" },
  { value: "tiles", label: "Tiles" },
  { value: "blocks", label: "Blocks" },
  { value: "roofing", label: "Roofing" },
  { value: "plumbing", label: "Plumbing" },
  { value: "electrical", label: "Electrical" },
  { value: "paint", label: "Paint" },
  { value: "glass", label: "Glass" },
]

export default function ProductsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [isLoading, setIsLoading] = useState(false)

  // Filter products based on search term and category
  const filteredProducts = products.filter((product) => {
    const matchesSearch = product.title.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "all" || product.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const handleSearch = () => {
    setIsLoading(true)
    // Simulate loading state
    setTimeout(() => {
      setIsLoading(false)
    }, 500)
  }

  const handleCategoryChange = (value: string) => {
    setIsLoading(true)
    setSelectedCategory(value)
    // Simulate loading state
    setTimeout(() => {
      setIsLoading(false)
    }, 500)
  }

  return (
    <main className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[40vh] w-full">
        <div className="absolute inset-0 bg-black/60 z-10" />
        <div
          className="absolute inset-0 bg-cover bg-center z-0"
          style={{
            backgroundImage: "url('/placeholder.svg?text=Construction+Materials+Display&height=800&width=1600')",
          }}
        />
        <div className="relative z-20 container mx-auto px-4 h-full flex flex-col justify-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Our Products</h1>
          <p className="text-xl text-white/90 max-w-2xl">
            Explore our wide range of high-quality construction materials
          </p>
        </div>
      </section>

      {/* Products Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          {/* Filters */}
          <div className="mb-12 flex flex-col md:flex-row gap-4">
            <div className="relative flex-grow">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <Input
                type="text"
                placeholder="Search products..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyUp={(e) => e.key === "Enter" && handleSearch()}
              />
            </div>
            <Select value={selectedCategory} onValueChange={handleCategoryChange}>
              <SelectTrigger className="w-full md:w-[200px]">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category.value} value={category.value}>
                    {category.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Products Grid */}
          {isLoading ? (
            <div className="flex justify-center items-center py-20">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
            </div>
          ) : filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  title={product.title}
                  description={product.description}
                  image={product.image}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <h3 className="text-xl font-semibold mb-2">No products found</h3>
              <p className="text-gray-600 mb-4">Try adjusting your search or filter criteria</p>
              <Button
                onClick={() => {
                  setSearchTerm("")
                  setSelectedCategory("all")
                }}
              >
                Reset Filters
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* Request Custom Order */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Can't Find What You Need?</h2>
          <p className="text-gray-700 max-w-2xl mx-auto mb-8">
            We can source custom materials based on your specific requirements. Contact us to discuss your needs and get
            a personalized quote.
          </p>
          <Button size="lg" asChild>
            <a href="/contact">Request Custom Order</a>
          </Button>
        </div>
      </section>
    </main>
  )
}

