import Image from "next/image"
import { CheckCircle } from "lucide-react"

export default function AboutPage() {
  return (
    <main className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[40vh] w-full">
        <div className="absolute inset-0 bg-black/60 z-10" />
        <div
          className="absolute inset-0 bg-cover bg-center z-0"
          style={{
            backgroundImage: "url('/placeholder.svg?text=Modern+Building+in+The+Gambia&height=800&width=1600')",
          }}
        />
        <div className="relative z-20 container mx-auto px-4 h-full flex flex-col justify-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">About Kanyi's Enterprise</h1>
          <p className="text-xl text-white/90 max-w-2xl">Your trusted partner in construction materials export</p>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row gap-12 items-center">
            <div className="md:w-1/2">
              <h2 className="text-3xl font-bold mb-6">Our Story</h2>
              <p className="text-gray-700 mb-4">
                Founded in 2015, Kanyi's Enterprise began with a simple mission: to bridge the gap between high-quality
                Turkish construction materials and the growing construction industry in The Gambia.
              </p>
              <p className="text-gray-700 mb-4">
                Our founder, Mr. Kanyi, recognized the challenges faced by construction companies in The Gambia when
                sourcing reliable and affordable building materials. With extensive experience in international trade
                and a network of trusted manufacturers in Turkey, he established Kanyi's Enterprise to address these
                challenges.
              </p>
              <p className="text-gray-700">
                Today, we have grown to become a leading supplier of construction materials, serving clients across The
                Gambia with a commitment to quality, affordability, and exceptional service.
              </p>
            </div>
            <div className="md:w-1/2">
              <Image
                src="/placeholder.svg?text=Founder+Meeting+with+Turkish+Suppliers&height=600&width=800"
                alt="Kanyi's Enterprise founder"
                width={800}
                height={600}
                className="rounded-lg shadow-lg w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="bg-white p-8 rounded-lg shadow-md">
              <h3 className="text-2xl font-bold mb-4">Our Mission</h3>
              <p className="text-gray-700">
                To provide high-quality construction materials at competitive prices, enabling our clients to build
                better, stronger, and more cost-effective structures. We aim to be the bridge that connects Turkish
                manufacturing excellence with The Gambian construction industry.
              </p>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-md">
              <h3 className="text-2xl font-bold mb-4">Our Vision</h3>
              <p className="text-gray-700">
                To become the premier supplier of construction materials in The Gambia, known for our unwavering
                commitment to quality, reliability, and customer satisfaction. We envision a future where every
                construction project in The Gambia has access to world-class building materials.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose Us</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <CheckCircle className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Direct Sourcing</h3>
                <p className="text-gray-700">
                  We work directly with manufacturers in Turkey, eliminating middlemen and ensuring you get the best
                  prices.
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <CheckCircle className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Quality Assurance</h3>
                <p className="text-gray-700">
                  All our products undergo rigorous quality checks before shipping to ensure they meet international
                  standards.
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <CheckCircle className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Comprehensive Service</h3>
                <p className="text-gray-700">
                  From sourcing to shipping to delivery, we handle the entire process, making it hassle-free for you.
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <CheckCircle className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Local Expertise</h3>
                <p className="text-gray-700">
                  Our team's understanding of both Turkish manufacturing and The Gambian construction industry ensures
                  you get the right products.
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <CheckCircle className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Flexible Payment Options</h3>
                <p className="text-gray-700">
                  We offer various payment methods and terms to accommodate your business needs.
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <CheckCircle className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Reliable Delivery</h3>
                <p className="text-gray-700">
                  Our established logistics network ensures your materials arrive on time, every time.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Team */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Our Leadership Team</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="w-32 h-32 mx-auto mb-4 overflow-hidden rounded-full">
                <Image
                  src="/placeholder.svg?text=CEO&height=300&width=300"
                  alt="CEO"
                  width={300}
                  height={300}
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-semibold mb-1">Lamin Kanyi</h3>
              <p className="text-gray-600 mb-3">Founder & CEO</p>
              <p className="text-gray-700">
                With over 15 years of experience in international trade, Lamin leads our company with vision and
                expertise.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="w-32 h-32 mx-auto mb-4 overflow-hidden rounded-full">
                <Image
                  src="/placeholder.svg?text=Operations+Director&height=300&width=300"
                  alt="Operations Director"
                  width={300}
                  height={300}
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-semibold mb-1">Fatou Jallow</h3>
              <p className="text-gray-600 mb-3">Operations Director</p>
              <p className="text-gray-700">
                Fatou oversees our day-to-day operations, ensuring smooth processes from order to delivery.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="w-32 h-32 mx-auto mb-4 overflow-hidden rounded-full">
                <Image
                  src="/placeholder.svg?text=Logistics+Manager&height=300&width=300"
                  alt="Logistics Manager"
                  width={300}
                  height={300}
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-semibold mb-1">Omar Ceesay</h3>
              <p className="text-gray-600 mb-3">Logistics Manager</p>
              <p className="text-gray-700">
                Omar's expertise in international shipping and customs ensures your materials arrive on time.
              </p>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}

